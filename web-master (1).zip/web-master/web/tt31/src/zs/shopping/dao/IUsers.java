package zs.shopping.dao;

import zs.shopping.pojo.Users;

public interface IUsers {
    public Users queryUsers(Users users);
}
