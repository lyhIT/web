package zs.shopping.dao;

import zs.shopping.pojo.Account;

public interface IAccount {

	Account queryAccount(Account account);

}
