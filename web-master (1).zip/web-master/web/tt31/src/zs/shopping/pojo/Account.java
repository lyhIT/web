package zs.shopping.pojo;

public class Account {
    private int aid;
    private String alogin;
    private String aname;
    private String apass;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAlogin() {
		return alogin;
	}
	public void setAlogin(String alogin) {
		this.alogin = alogin;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getApass() {
		return apass;
	}
	public void setApass(String apass) {
		this.apass = apass;
	}
    
}
